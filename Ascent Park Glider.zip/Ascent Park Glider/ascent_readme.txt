Model: E-flite Ascent Electric Park Glider ARF
Author: Gary Gunnerson
Email: garyg51384@aol.com
HomePage: http://gunnerson.homestead.com/files/fms_models.htm
Created: November 2007

Another RC modeler requested this model. I have never flown this
model so, please provide feedback regarding the flight characteristics.

Review http://www.rcgroups.com/forums/showthread.php?t=143224
E-flight http://www.e-fliterc.com/Products/TechnicalSpecs.aspx?ProdID=EFL1075
RC Groups http://www.rcgroups.com/forums/showthread.php?t=87671

Model Details:

Span	 54.0 in. 1.384m
Length	 32.0 in. 0.825m
Weight	 19.5 oz. 0.552kg
Channels 3 R/E/T
Battery  8-cell 1100 mAh
ESC	 15-20 AMP
Motor	 Speed 400
Prop	 folding 7x3
Material fiberglass fuselage, balsa Ultracote wings