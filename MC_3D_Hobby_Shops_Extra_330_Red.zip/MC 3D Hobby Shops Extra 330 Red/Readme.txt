This model was an FMS model by Mr. Shinichiro Nishiya and 
converted and Modified to Clearview using AC3D, by Michael Cofer. 
It was then updated to ver 5 params Then Ver 6. The paint scheme came from 
a fellow CV pilot /Bob Howell
To Install, simply extract 
the file and put the folder under the models in the Clearview 
RC Simulator.  The next time you run Clearview, it will appear 
under the Airplane selections.


 
 Michael Cofer
 mikecofer@wildblue.net