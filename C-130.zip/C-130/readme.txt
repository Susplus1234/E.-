This Model was created for FMS by Logic_Wizard and was modified by Ken Northup using AC3D and is freely distributed.  I slowed the effects of the aelerons quite considerably to give it the scale feeling...If you want a more responsive plane, change these settings in the params.txt 
(aelWashCoef 0.2) to 0.8
(aelCoef 0.1)to 0.2. Then you can adjust the rates for the surfaces. Please feel free to modify as you wish using AC3D.  If you modify and make a better paint scheme, feel free to contact me via email, as I would love to see different versions created for Clearview RC Simulator.  To Install, simply extract the file and put the folder under the models in the Clearview RC Simulator.  The next time you run Clearview, it will appear under the Airplane selections.

Ken Northup	
Helos360@bellsouth.net